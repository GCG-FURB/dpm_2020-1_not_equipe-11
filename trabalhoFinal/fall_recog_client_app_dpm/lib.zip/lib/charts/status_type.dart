enum StatusType {
  DESCONHECIDO,
  POSITIVO,
  NEGATIVO,
}